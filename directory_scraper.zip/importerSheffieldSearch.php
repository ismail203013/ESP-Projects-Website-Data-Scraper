<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerSheffieldSearch extends importer {

    protected $connection;
    protected $source = "Sheffield Search";
    protected $url = "http://www.sheffieldsearch.co.uk/business-directory/";

    function getCategories()
    {
       $html = $this->getHTML($this->url);
       
       $categories =[];     

        foreach ($html->find('.bdc') as $bdc) 
        {
            $categoryName = $bdc->find('h2 a', 0)->plaintext;
            $categoryLink = $bdc->find('h2 a', 0)->href;
            // $categories[] = array(
            //     'name' => $categoryName,
            //     'link' => $categoryLink
            // );
            $category = new stdClass();
            $category->category = $categoryName;
            $category->url =  $this->url . $categoryLink;

            array_push($categories,$category);
        }
        return $categories ;
        
    }
   
    function getItems($category)
   {
      $items = [];

      $html = $this->getHTML($category->url);
 
     // $item = ".resource-heading";
 
     $Elements = $html->find('.r');

     foreach ($Elements as $resourceDetail) {
 
         // Find the business name
         $businessName = $resourceDetail->find('.c-2 h2 a', 0)->plaintext;
         $addressElement = $resourceDetail->find('p.address', 0);
         $phoneNumber = '';
         if ($addressElement) {
             // Remove HTML tags and trim the text
             $plainText = trim(strip_tags($addressElement->plaintext));
         
             // Find the position of the 'Tel:' keyword
             $telKeyword = 'Tel:';
             $telIndex = strpos($plainText, $telKeyword);
         
             if ($telIndex !== false) {
                 // Extract the phone number by removing everything before 'Tel:'
                 $phoneNumber = trim(substr($plainText, $telIndex + strlen($telKeyword)));
             }
         }
             $updatesource = $this->source;
 
             if ($businessName && $phoneNumber) {               
                 $item = new directoryItem();
                 $item->title = $businessName;
                 $item->phoneNumber = $phoneNumber;
                 $item->website = "";
                 $item->email = "";
                 $item->source = $updatesource;
                 $item->category = $category->category;
 
                 array_push($items,$item);
               //  echo "Company Name: " . $companyName . ", <br> Phone: " . $phoneNo . PHP_EOL;
             }
            // echo "<br>";
             //echo "<br>";
         }
   
       
     return $items;
     
    
   }

}
