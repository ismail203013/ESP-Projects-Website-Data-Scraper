<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerBusinessDirectory extends importer 
{
  protected $connection;
  protected $source = 'Business Directory';
  protected $url = "http://www.business-directory.org.uk/free-business-directory/Sheffield.html";

  protected $paging = true;
  
    
  function getCategories()
  {

    $html = $this->getHTML($this->url);
       
    $categories =[];     

    foreach ($html->find('.catsub') as $x) 
    {
      $categoryName = $x->find('a' , 0)->plaintext;
      $categoryLink = $x->find('a' , 0)->href;

      $category = new stdClass();
      $category->category = $categoryName ;
      $category->url = "http://www.business-directory.org.uk" . $categoryLink ;

      if (empty($categories[$categoryName]))
      {
        $categories[$categoryName] = $category;

      }
    }  
    return $categories;  
  }
 
  
  function getItems($category)
  {
    $items = [];

 

      $categoryUrl = $category->url;
      $categoryType = $category->category ;

      $html = $this->getHTML($categoryUrl);

      foreach ($html->find('table[style="border-collapse: collapse"]') as $x) 
      {
        $ItemLink = $x->find('a' , 0)->href;

        $itemLink = "http://www.business-directory.org.uk" . $ItemLink ;
        $item = $this->getItemDetails($itemLink , $categoryType);

        array_push($items,$item);

      }
      return $items ;
    
  } 

  function getItemDetails($itemLink , $categoryType)
  {  
    $item = null ;

    $html = $this->getHTML($itemLink);


    $companyNames = $html->find('h1.navtop');
    $phoneNumbers = $html->find('span[itemprop="telephone"] li');
    $urlElements = $html->find('a[itemprop="url"]');

    foreach ($companyNames as $index => $companyName) 
    {
      $companyName = $companyName->plaintext;
      $phoneNo = isset($phoneNumbers[$index]) ? $phoneNumbers[$index]->plaintext : "";
      $urlElement = isset($urlElements[$index]) ? $urlElements[$index]->plaintext : "";
                
      $updatesource = $this->source;
    
      $item = new directoryItem();
      $item->title = $companyName;
      $item->phoneNumber = $phoneNo;
      $item->website = $urlElement;
      $item->email = "";
      $item->source = $updatesource;
      $item->category = $categoryType;
    
    }
    return $item;

  }



}