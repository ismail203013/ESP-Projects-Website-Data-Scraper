<?php
// Database configuration
$host = "localhost";
$username = "develop";
$password = "akGlzYCByta8iHJ";
$database = "develop";

// Create a database connection
$connection = new mysqli($host, $username, $password, $database);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

echo "Database connected successfully";
?>


<!DOCTYPE html>
<html>
<head>
    <title>PHP Data Scrapper</title>
</head>
<body>
    <h1>Directories</h1>

    <table border="1">
        <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Last Refreshed</th>
            <th>Action</th>
        </tr>
        <?php

        // $sql = "SELECT name FROM directories";
        // $result = $connection->query($sql);

        // if ($result->num_rows > 0) 
        // {
        //     while ($row = $result->fetch_assoc()) 
        //     {
        //     echo "<tr><td>" .$row["name"]     .  "</td>";
        //     }
        // } 
        // else {echo "No results found.";}
       

        $items_count = "SELECT  directories.name as source, refresh_time, COUNT(directory_items.id) as total_items
        FROM directories
        LEFT JOIN directory_items on directory_items.source = directories.name
        GROUP BY directories.name , refresh_time";
        $items_count_result = $connection->query($items_count);

        if ($items_count_result->num_rows > 0) 
        {
        while ($row = $items_count_result->fetch_assoc()) 
        {
        echo "<tr><td>" .$row["source"]     .  "</td>";
        echo "<td>" . $row["total_items"] . "</td>";
        
        if (!empty($row["refresh_time"]))
        {
            $date=date_create($row["refresh_time"]);
            $date=date_format($date,"d/m/Y H:i:s");
        }
        else{$date="";}
        
        echo "<td>" .  $date . "</td>";
        echo "<td> <a href='/runImport.php?directory=" . $row['source'] . "'> Refresh </a> </td></tr>";
        }
        } 
        else 
        {
        echo "No results found.";
        }


$connection->close(); 

        ?>
        </tr>
    </table>
</body>
</html>
