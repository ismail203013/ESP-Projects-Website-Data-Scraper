<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerBusinessMagnet extends importer {

    protected $connection;
    protected $source = 'Business Magnet';
    protected $url = "https://www.businessmagnet.co.uk/town/sheffield.htm";

    function getItems($category){
   
      $items = [];
  
      $html = $this->getHTML($category->url);
  
      $item = ".indexinglist";
  
      $ulElement = $html->find($item, 0);
      
      if ($ulElement) {
          // Get all <li> tags within the element with class "indexinglist"
          $liTags = $ulElement->find("li");
      
          // Loop through each <li> tag and print the company name and phone
          foreach ($liTags as $liTag) {
              // Find the <a> tag within the <li> tag
              $aTag = $liTag->find("a", 0);
              // Find the <span> tag within the <li> tag
              $spanTag = $liTag->find("span[class=company-phone]", 0);
              //if there are found then get phone no and store them and output 
               $updatesource = $this->source;
  
              if ($aTag && $spanTag) {
                  $companyName = $aTag->plaintext;
                  $phoneNo = $spanTag->getAttribute("phoneno");
                  $item = new directoryItem();
                  $item->title = $companyName;
                  $item->phoneNumber = $phoneNo;
                  $item->website = "";
                  $item->email = "";
                  $item->source = $updatesource;
                  $item->category = $category->category;
  
                  array_push($items,$item);
                //  echo "Company Name: " . $companyName . ", <br> Phone: " . $phoneNo . PHP_EOL;
              }
             // echo "<br>";
              //echo "<br>";
          }
      } else 
        {
          echo "Element with class '" . $item . "' not found.";
        }
      return $items;
      
     } 

}
  

?>