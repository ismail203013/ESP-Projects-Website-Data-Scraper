<?php

require 'vendor/autoload.php';

use GuzzleHttp\Client;

class CategoryExtractor

{ 
    private $connection;
    private $source = '';
    private $url = "http://www.sheffieldsearch.co.uk/business-directory/";
    private $client;

    
    // function __construct()
    // {
    //     $servername = "localhost";
    //     $username = "develop";
    //     $password = "akGlzYCByta8iHJ";
    //     $database = "develop";
        
    //     // Create connection
    //     $this->connection = new mysqli($servername, $username, $password, $database);
    // }

    function getHTML() 
    {
        include('simple_html_dom.php');

        $client = new Client
        ([
           // Base URI is used with relative requests
           'base_uri' => $this->url,
           'headers' => [
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        ],
        ]);
   
        $response = $client->request('GET', '');
   
        $response_body = (string) $response->getBody();
   
        $html = str_get_html($response_body);
    
        return $html;
    }

    function getCategories()
    {
       $html = $this->getHTML();
       
       $categories =[];     

        foreach ($html->find('.bdc') as $bdc) 
        {
            $categoryName = $bdc->find('h2 a', 0)->plaintext;
            $categoryLink = $bdc->find('h2 a', 0)->href;
            // $categories[] = array(
            //     'name' => $categoryName,
            //     'link' => $categoryLink
            // );
            $category = new stdClass();
            $category->category = $categoryName ;
            $category->categoryLink =  $categoryLink ;

            array_push($categories,$category);
        }
        return $categories ;
    }

    function getCategoryLinks() 
    {

        $categories = $this->getCategories();
        $categoryHTMLs = [];

        foreach ($categories as $category)
        {
            $categoryLink = $category->categoryLink;

            $client = new Client
         ([
           // Base URI is used with relative requests
           'base_uri' => $this->url,
           'headers' => [
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
         ],
         ]);
       
            $response = $client->request('GET', "$categoryLink");

           
   
            $response_body = (string) $response->getBody();
      
            $html = str_get_html($response_body);
            $dataCategory = ($category->category);
            $this->storeCategoryItems($html, $dataCategory);

        
        }

        

    }

    function storeCategoryItems($html, $dataCategory )
    {

        $importer = new importerSheffieldSearch();
        $items = $importer->getCategoryItems($html, $dataCategory);
        $importer->storeItems($items);
    }

    // function storeCategory($item){

    //     $tableName = 'directory_items';
    
    //     // Prepare and execute the INSERT query
    //     // $stmt = $this->connection->prepare("INSERT INTO $tableName (title, phoneNumber, website, email) VALUES (?, ?, ?, ?)");
        
    //     foreach ($item as $i) {
    
    //         $existingItemId = $this->getItemId($i);
              
    //         print_r($existingItemId);
    
    //         echo"<br>";
    
    //         if ($existingItemId == true) {
    //                 // Item already exists, update the record instead of inserting a new one
    //         // Prepare the UPDATE query
    //         $updateStmt = $this->connection->prepare("UPDATE directory_items SET phoneNumber=?, category=?, categoryLink=?, website=?, email=? WHERE title = ? AND source = ?");
            
    //         // Bind the parameters for the update
    //         $updateStmt->bind_param("sssssss", $i->phoneNumber, $i->category, $i->categoryLink, $i->website, $i->email, $i->title, $i->source);
            
    //         // Execute the update query
    //         $updateStmt->execute();
            
    //         // Close the statement
    //         $updateStmt->close();
    
    
    
    //         } else {
    //             // Item doesn't exist, you can proceed with inserting it
    //             // Prepare the INSERT query
    //             $insertStmt = $this->connection->prepare("INSERT INTO directory_items (title, phoneNumber, category, categoryLink, website, email, source) VALUES (?, ?, ?, ?, ?)");
                
    //             // Bind the parameters
    //             $insertStmt->bind_param("sssssss", $i->title, $i->phoneNumber, $i->category, $i->categoryLink, $i->website, $i->email, $i->source);
                
    //             // Execute the query to insert the new item
    //             $insertStmt->execute();
                
    //             // Close the statement
    //             $insertStmt->close();
    //         }
    
    
    //         // Bind the parameters
    //        // $stmt->bind_param("ssss", $item->title, $item->phoneNumber, $item->website, $item->email);
        
    //         // Execute the query
    //         //$stmt->execute();
        
    
    //    }
      
       }
   



