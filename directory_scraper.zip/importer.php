<?php

require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importer {

    protected $connection;
    protected $source;
    protected $url;

    protected $paging = false;
    protected $itemsPerPage = 1;
    protected $maxPage;
    protected $page;
    

    function __construct()
    {
        $servername = "localhost";
        $username = "develop";
        $password = "akGlzYCByta8iHJ";
        $database = "develop";
        
        // Create connection
        $this->connection = new mysqli($servername, $username, $password, $database);

        //check paging
        if($this->paging)
        {
            $this->page = !empty($_GET['page']) ? $_GET['page'] : 1 ;
        }
        
    }

    

    function run()
    {
       $categories = $this->getCategories();
       if($this->paging)
       {
        $this->maxPage = ceil(count($categories)/$this->itemsPerPage);
        $start = ($this->page - 1) * $this->itemsPerPage;
        $categories = array_slice($categories, $start , $this->itemsPerPage );
       }
       foreach ($categories as $category)
       {
        
         $items = $this->getItems($category);
         $this->storeItems($items);
       }
       if($this->paging && $this->page < $this->maxPage)
       {
            $redirect = '/runImport.php?directory=' . $this->source . '&page=' . $this->page + 1 ;
       }
       else 
       {
        $redirect = '/';
       }

    
    

       $currentTimestamp = date('Y-m-d H:i:s');
       $updateStmt = $this->connection->prepare("UPDATE directories SET refresh_time = ? WHERE name = ?");
       $updateStmt->bind_param("ss", $currentTimestamp, $this->source);
       $updateStmt->execute();
       $updateStmt->close();
       
        header("Location: $redirect");

    }
    function getCategories()
    {
        $category = new stdClass();
        $category->category = "" ;
        $category->url = $this->url ;
        $categories = [$category];
        return $categories;

    }
  
   function getItems($category)
   {
   
        // function must be overidden
    
   }

   function getHTML($url) 
   {
    $rawHtml = $this->getRawHTML($url);
    
    $html = str_get_html($rawHtml);
 
    return $html;

   }

   function getRawHTML($url) 
   {
    
     $client = new Client
     ([
        // Base URI is used with relative requests
        'base_uri' => $url,
        'headers' => [
         'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
     ],
     ]);

     $response = $client->request('GET', '');

     $rawHtml = (string) $response->getBody();
 
     return $rawHtml;

   }


   function getItemId($item)
   {

    $stmt = $this->connection->prepare("SELECT id FROM directory_items WHERE title = ? AND source = ?");

    // Bind the parameter (assuming title is the unique identifier)
    $stmt->bind_param("ss", $item->title, $item->source);

    // Execute the query
    $stmt->execute();

    // Bind the result to a variable
    $stmt->bind_result($existingItemId);

    // Fetch the result
    $stmt->fetch();

    // Close the statement
    $stmt->close();


    return $existingItemId;

   }

   function storeItems($items){

    $tableName = 'directory_items';

    // Prepare and execute the INSERT query
    // $stmt = $this->connection->prepare("INSERT INTO $tableName (title, phoneNumber, website, email) VALUES (?, ?, ?, ?)");
    
    foreach ($items as $item) {

        $existingItemId = $this->getItemId($item);
          

        if ($existingItemId == true) {
                // Item already exists, update the record instead of inserting a new one
        // Prepare the UPDATE query
        $updateStmt = $this->connection->prepare("UPDATE directory_items SET phoneNumber=?, category=? , website=?, email=? WHERE title = ? AND source = ?");
        
        // Bind the parameters for the update
        $updateStmt->bind_param("ssssss", $item->phoneNumber, $item->category, $item->website, $item->email, $item->title, $item->source);
        
        // Execute the update query
        $updateStmt->execute();
        
        // Close the statement
        $updateStmt->close();



        } else {
            // Item doesn't exist, you can proceed with inserting it
            // Prepare the INSERT query
            $insertStmt = $this->connection->prepare("INSERT INTO directory_items (title, phoneNumber, category , website, email, source) VALUES (?, ?, ?, ?, ?, ?)");
            
            // Bind the parameters
            $insertStmt->bind_param("ssssss", $item->title, $item->phoneNumber, $item->category, $item->website, $item->email, $item->source);
            
            // Execute the query to insert the new item
            $insertStmt->execute();
            
            // Close the statement
            $insertStmt->close();
        }


        // Bind the parameters
       // $stmt->bind_param("ssss", $item->title, $item->phoneNumber, $item->website, $item->email);
    
        // Execute the query
        //$stmt->execute();
    

   }
  
   }

}

?>