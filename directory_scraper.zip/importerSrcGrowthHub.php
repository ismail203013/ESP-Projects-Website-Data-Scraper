<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerSrcGrowthHub extends importer {

    protected $connection;
    protected $source = 'SCR Growth Hub';
    protected $url = "https://www.scrgrowthhub.co.uk/wp-json/scrgh-directory/v1/listings";

    function getItems($category){
   
      $items = [];
  
      $html = $this->getHTML($category->url);
  
      $data = json_decode($html);
  
      foreach ($data as $dataItem )
      {
          $item = new directoryItem();
          $item->title = $dataItem->title;
          $item->phoneNumber = $dataItem->telephone;
          $item->website = $dataItem->website;
          $item->email = $dataItem->email;
          $item->source = $this->source;
          $item->category = $category->category;
  
          array_push($items,$item);
      }
        return $items;
      
     } 

}

?>