<?php

require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerTheBestOf extends importer {

    protected $connection;
    protected $source = "The Best Of";
    protected $url = "https://www.thebestof.co.uk/local/sheffield/business-guide/az/";

    function getItems($category)
   {
   
        
    $items = [];

    $html = $this->getHTML($category->url);

   // $item = ".resource-heading";

    $Elements = $html->find('.resource-details');
    
    foreach ($Elements as $resourceDetail) {

        // Find the business name
        $businessName = $resourceDetail->find('.resource-heading a', 0)->plaintext;
    
        // Find the phone number from the resource-actions
        $phoneNumberElement = $resourceDetail->find('.resource-action a[href^="tel:"] span.resource-action-label', 0);
        $phoneNumber = $phoneNumberElement ? $phoneNumberElement->plaintext : "N/A";
    
       
            $updatesource = $this->source;

            if ($businessName && $phoneNumber) {               
                $item = new directoryItem();
                $item->title = $businessName;
                $item->phoneNumber = $phoneNumber;
                $item->website = "";
                $item->email = "";
                $item->source = $updatesource;
                $item->category = $category->category;

                array_push($items,$item);
              //  echo "Company Name: " . $companyName . ", <br> Phone: " . $phoneNo . PHP_EOL;
            }
           // echo "<br>";
            //echo "<br>";
        }
  
      
    return $items;
    
   } 

}

   
?>