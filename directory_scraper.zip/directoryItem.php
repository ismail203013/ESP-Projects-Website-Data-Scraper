<?php 

class directoryItem 
{

    public $title;
    public $phoneNumber;
    public $website;
    public $email;
    public $source;
    public $category;

}