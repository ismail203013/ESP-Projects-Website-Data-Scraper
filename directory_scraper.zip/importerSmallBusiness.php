<?php 
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerSmallBusiness extends importer 
{

    protected $connection;
    protected $source = 'UK Small Business';
    protected $url = "https://www.uksmallbusinessdirectory.co.uk/town/sheffield/";

  
    function getCategories(){
   
    $html = $this->getHTML($this->url);

    $categories =[];   

    // find all divs
    $elements = $html->find('div'); 

    foreach ($elements as $element) 
    {
        $style = $element->getAttribute('style');
        
        // Check if the style attribute contains "margin-bottom:10px;"
        if (strpos($style, 'margin-bottom:10px;') !== false) 
        {
            $firstATag = $element->find('a', 0 );
            $secondATag = $element->find('a', 1);
            $categoryLink = $firstATag->getAttribute('href');
            $categoryName = $secondATag->plaintext;

            $category = new stdClass();
            $category->category = $categoryName;
            $category->url = $categoryLink;

            array_push($categories,$category);
        }
    }
    return $categories;


    
//        echo("fdsf");
//    exit;
//        $startPos = strpos($html,"border-color: #e7b816", 0 );
    
//        $endPos = strpos($html,"</div></div>", $startPos );

//        $itemHtml = substr ($html , $startPos , $endPos - $startPos);

//        $itemHtml = str_get_html($itemHtml);
//        $firstATag = $itemHtml->find('a', 0 );
//        $secondATag = $itemHtml->find('a', 1);
//        $itemDetailLink = $firstATag->getAttribute('href');
//        $categoryName = $secondATag->plaintext;

//        echo $itemDetailLink ;
//        echo "<br>" ;
//        echo $categoryName ;





//        exit;







//         $items =[];  

//         print_r ($html->find(
//             'div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #e7b816;"],
//             div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #999999;"],
//             div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #c09500;"]'
//         ));
//         exit;
 
//          foreach ($html->find(
//              'div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #e7b816;"],
//              div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #999999;"],
//              div[style="margin-bottom:10px; border:1px solid; border-radius:0px; border-color: #c09500;"]'
//          ) as $div) 
//          {   
           
//             $firstATag = $div->find('a', 0 );
//             $secondATag = $div->find('a', 1);
//             $itemDetailLink = $firstATag->getAttribute('href');
//             $categoryName = $secondATag->plaintext;

//             $item = $this->getItemsDetails($itemDetailLink, $categoryName);

//             if ($item)
//             {
//                 array_push($items,$item);
//             }
 
             
//          } 
//          print_r ($items);
//          exit;
//          return $items ;

        
        
    } 

    function getItems($category){

        $items = [];
    
        $html = $this->getHTML($category->url);

        // $test = $categories->url;

        $h1Tags = $html->find('.formcontainer h1');

        if(empty($h1Tags))
        {
            $h1Tags = $html->find('.txtcontainer h1');
        }

        foreach ($h1Tags as $index => $h1Tag) {
            // Extract the company name from the <h1> tag
            $company_name = $h1Tag->plaintext;

            $formContainer = $h1Tag->parent();

            // Initialize phone number and website URL as empty strings
            $phone_number = '';
            $website_url = '';

            // Extract the phone number directly from the form container
            preg_match('/(?:\+44\s?)?\d{2,4}\s?\d{3,4}\s?\d{4}\b/', $formContainer->plaintext, $matches);

            if (!empty($matches[0])) {
                $phone_number = $matches[0];
                
            }
            else{ $phone_number = "N/A";}

            // Find the website URL within the form container
            $websiteElement = $formContainer->find('a[rel=sponsored]', 0);
            if ($websiteElement) {
                $website_url = $websiteElement->href;
               
            }
            $updatesource = $this->source;
            // Store the extracted information in the $items array
            if (!empty($company_name)) {
                $item = new directoryItem();
                $item->title = $company_name;
                $item->phoneNumber = $phone_number;
                $item->website = $website_url;
                $item->email = "";
                $item->source = $updatesource; // Assuming $this->source contains the correct source value
                $item->category = $category->category;
                
                array_push($items,$item);
            }
            
   
        } 
           
        return $items;

    }


}