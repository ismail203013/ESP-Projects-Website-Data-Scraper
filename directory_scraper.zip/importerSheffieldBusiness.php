<?php 
require 'vendor/autoload.php';

use GuzzleHttp\Client;

class importerSheffieldBusiness extends importer 
{

    protected $connection;
    protected $source = 'Sheffield Business Directory';
    protected $url = "http://www.sheffield-business.co.uk/";

    function getCategories()
    {
        $html = $this->getHTML($this->url);
           
        $categories = [];
    
        foreach ($html->find('.serviceshome') as $x) 
        {
            $categoryItems = $x->find('li');
    
            foreach ($categoryItems as $categoryItem) 
            {
                $categoryName = $categoryItem->plaintext;
                $categoryLink = $categoryItem->find('a', 0)->href;
    
                $category = new stdClass();
                $category->category = $categoryName;
                $category->url = "http://www.sheffield-business.co.uk/" . $categoryLink;
    
                if (empty($categories[$categoryName]))
                {
                    $categories[$categoryName] = $category;
                }
            }
        }
     array_pop($categories);
     return $categories;
    }


    function getItems($category)
  {
    $items = [];

    $categoryUrl = $category->url;
    $categoryType = $category->category ;

    $html = $this->getHTML($categoryUrl);
    $a_tags = $html->find('a[style="padding-left:0px;"]');

    foreach ($a_tags as $x) 
    {
        $ItemLink = $x->href;

        $itemLink = "http://www.sheffield-business.co.uk/" . $ItemLink ;
        $item = $this->getItemDetails($itemLink , $categoryType);

        array_push($items,$item);

    }
    return $items ;
  } 

  function getItemDetails($itemLink , $categoryType)
  {  
    $item = null ;

    $html = $this->getHTML($itemLink);

    $companyNames = $html->find('h1' , 0); 
    if($companyNames)
    {
     $companyName = $companyNames->plaintext;
    }
    
    else {$companyName = "";}
   

   
    // Extract phone 
    $telephone_start = strpos($html, 'Telephone:');
    if ($telephone_start !== false) {
        $telephone_end = strpos($html, '<br', $telephone_start);
        if ($telephone_end !== false) {
            $telephone_number = substr($html, $telephone_start + strlen('Telephone:'), $telephone_end - $telephone_start - strlen('Telephone:'));
            $telephone_number = trim($telephone_number);
            $telephone_number = str_replace("</b>", "", $telephone_number);
        } else {
            $telephone_number = "N/A";
        }
    } else {
        $telephone_number = "N/A";
    }

  


    // Extract Email
    $email_start = strpos($html, 'Email:');
    if ($email_start !== false) 
    {
     $email_end = strpos($html, '<br', $email_start);
        if ($email_end !== false) 
        {
        $email = substr($html, $email_start + strlen('Email:'), $email_end - $email_start - strlen('Email:'));
        $email = trim($email);
        $email = str_replace("</b>", "", $email);
        } 
        else 
        {
        $email = "N/A";
        }
    }   
         else 
    {
        $email = "N/A";
    }

    

// Extract Website
    $website_start = strpos($html, 'Website:');
    if ($website_start !== false) 
    {
        $website_end = strpos($html, '</a>', $website_start);
        if ($website_end !== false) 
        {
            $website_link = substr($html, $website_start + strlen('Website:'), $website_end - $website_start - strlen('Website:'));
            $website_link = trim(strip_tags($website_link)); // Remove any HTML tags
        } 
        else 
        {
            $website_link = "N/A";
        }
    } 
    else    
    {
        $website_link = "N/A";
    }

    


      $updatesource = $this->source;
    
      $item = new directoryItem();
      $item->title = $companyName;
      $item->phoneNumber = $telephone_number;
      $item->website = $website_link;
      $item->email = $email;
      $item->source = $updatesource;
      $item->category = $categoryType;
    
    
    return $item;

  }



}