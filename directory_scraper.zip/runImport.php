<?php 

require_once 'importer.php';
require_once 'directoryItem.php';
require_once 'simple_html_dom.php';

$directory = $_GET['directory'];

switch($directory)
{
 case "Business Magnet" : 
    require_once 'importerBusinessMagnet.php';
    $importer = new importerBusinessMagnet();
    break;

    case "SCR Growth Hub" : 
        require_once 'importerSrcGrowthHub.php';
        $importer = new importerSrcGrowthHub();
        break;

    case "The Best Of" : 
        require_once 'importerTheBestOf.php';
        $importer = new importerTheBestOf();
        break;

        case "Sheffield Search" : 
            require_once 'importerSheffieldSearch.php';
            $importer = new importerSheffieldSearch();
            break;
    
        case "UK Small Business" : 
            require_once 'importerSmallBusiness.php';
            $importer = new importerSmallBusiness();
            break;

            case "Business Directory" : 
                require_once 'importerBusinessDirectory.php';
                $importer = new importerBusinessDirectory();
                break;
        
            case "Sheffield Business Directory" : 
                require_once 'importerSheffieldBusiness.php';
                $importer = new importerSheffieldBusiness();
                break;

 default : 

    echo "Directory not found";
    $importer = false;

    break;
}
    if($importer)
    {
     
      $items = $importer->run();

    }
